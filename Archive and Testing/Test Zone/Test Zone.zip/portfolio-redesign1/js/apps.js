/* =========================================================
   apps.js — loaded in the <head> of every page (no defer)
   so the saved theme is applied before the page paints.
   The only job: the dark mode button.
   ========================================================= */
(function () {
  var KEY = "theme";
  var root = document.documentElement;

  var saved = null;
  try { saved = localStorage.getItem(KEY); } catch (e) { /* storage blocked */ }
  if (saved === "light" || saved === "dark") {
    root.setAttribute("data-theme", saved);
  }

  function currentTheme() {
    var chosen = root.getAttribute("data-theme");
    if (chosen) {
      return chosen;
    }
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return "dark";
    }
    return "light";
  }

  document.addEventListener("DOMContentLoaded", function () {
    var button = document.querySelector("[data-theme-toggle]");
    if (!button) {
      return;
    }

    function sync() {
      var isDark = currentTheme() === "dark";
      button.setAttribute("aria-pressed", isDark ? "true" : "false");
    }

    button.addEventListener("click", function () {
      var next = currentTheme() === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      try { localStorage.setItem(KEY, next); } catch (e) { /* storage blocked */ }
      sync();
    });

    sync();
  });
})();
