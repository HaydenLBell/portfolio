# haydenbell.co.uk

My portfolio site: a home page, a projects index, and a write-up page for each featured project.

Plain HTML, CSS and a few lines of JavaScript. No build step, no framework, no third-party requests. It's hosted on GitHub Pages from this repo, and the custom domain is set in `CNAME`.

## Layout

```
index.html                 home: intro, selected work, experience, skills
projects.html              every project, grouped by area
projects/*.html            one page per featured project
css/styles.css             the only stylesheet (colours and spacing are tokens at the top)
js/apps.js                 dark mode toggle, remembered in localStorage
assets/fonts/archivo.woff2 Archivo variable font (SIL Open Font License), self-hosted
assets/                    photo and CVs
```

## Run it locally

```
python3 -m http.server
```

Then open http://localhost:8000.

## Adding a project

1. Copy an existing page in `projects/` and rename it.
2. Fill in the facts list and sections. Lines marked `WRITE:` in comments are prompts for what to add.
3. Put any images in `assets/projects/<project-name>/`.
4. Add a card to `projects.html` (copy an existing `<a class="card">`). If it's a favourite, add one to the selected work on `index.html` too.
5. Card pictures go at `assets/projects/<project-name>/card.jpg` (16:9). Uncomment the `<img>` line inside that card's `card-media`. Until then the card shows a circuit pattern.
