/* =========================================================
   apps.js — loaded in the <head> of every page (no defer)
   so a saved theme is applied before the page paints.

   Theme: follows the system setting until the visitor uses
   the switch, then remembers their choice.
   ========================================================= */
(function () {
  var KEY = "theme";
  var root = document.documentElement;
  var systemDark = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

  var saved = null;
  try { saved = localStorage.getItem(KEY); } catch (e) { /* storage blocked */ }
  if (saved === "light" || saved === "dark") {
    root.setAttribute("data-theme", saved);
  }

  function currentTheme() {
    var chosen = root.getAttribute("data-theme");
    if (chosen) {
      return chosen;
    }
    if (systemDark && systemDark.matches) {
      return "dark";
    }
    return "light";
  }

  document.addEventListener("DOMContentLoaded", function () {
    var toggle = document.querySelector(".theme-toggle");
    if (!toggle) {
      return;
    }

    function sync() {
      var isDark = currentTheme() === "dark";
      toggle.setAttribute("aria-checked", isDark ? "true" : "false");
    }

    toggle.addEventListener("click", function () {
      var next = currentTheme() === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      try { localStorage.setItem(KEY, next); } catch (e) { /* storage blocked */ }
      sync();
    });

    // If the visitor hasn't picked a theme, keep the switch in step with the system
    if (systemDark && systemDark.addEventListener) {
      systemDark.addEventListener("change", sync);
    }

    sync();
  });
})();
